package com.example.bankk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankkApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankkApplication.class, args);
	}

}
